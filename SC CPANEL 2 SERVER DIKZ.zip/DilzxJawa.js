
// Dikz
const TelegramBot = require('node-telegram-bot-api');
const { Telegraf, Markup, Input } = require("telegraf");
const fs = require('fs');
const axios = require('axios');
const chalk = require('chalk');
const pino = require('pino');
const crypto = require('crypto');
const FormData = require('form-data');
const moment = require('moment-timezone');
const Client = require("ssh2");
const settings = require('./settings')
const botToken = settings.token;
const owner = settings.adminId;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumUsers.json';
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
const domainV2 = settings.domainV2;
const pltaV2 = settings.pltaV2;
const pltcV2 = settings.pltcV2;
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
const bot = new TelegramBot(botToken, { polling: true });
const Cokli = 'https://files.catbox.moe/9d6cf4.png';
const Music = 'https://files.catbox.moe/hm0owr.mp3';
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
}

function getRunDuration(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
const nama = 'DikzMarket01';
const author = 'DikzMarket01';
const version = '1.0';
// Informasi waktu mulai bot
const startTime = Date.now();
   
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const startTime = Date.now();
    const sender = msg.from.username;
   

    const DilzxMenu = `
Hallo @${sender} I Am a Cpanel Bot By DikzMarket01 Vip. If there are any problems such as bugs, you can contact the admin @DikzMarket01 Thank You. Please select the menu below, Happy Using And Enjoy\n\n ╭─❍ 𝑺𝑬𝑳𝑬𝑪𝑻 𝑻𝑶 𝑴𝑬𝑵𝑼\n│ ▢ ᴏᴡɴᴇʀᴍᴇɴᴜ  \n│ ▢ ᴄᴘᴀɴᴇʟᴍᴇɴᴜ \n│ ▢ ᴄᴘᴀɴᴇʟᴍᴇɴᴜ² (ᴄᴏᴍɪɴɢ sᴏᴏɴ) \n│ ▢ ғᴜɴᴍᴇɴᴜ (ᴄᴏᴍɪɴɢ sᴏᴏɴ)\n│ ▢ ᴘᴀʏᴍᴇɴᴛ \n╰─────────────\n\n╭─❍ 𝑻𝑯𝑨𝑵𝑲 𝑻𝑶\n│▢ 𝗔𝗟𝗟𝗔𝗛 ⟬ ᴍʏ ɢᴏᴅ ⟭\n│▢ 𝗕𝗢𝗧𝗛 𝗣𝗔𝗥𝗘𝗡𝗧𝗦\n│▢ 𝗗𝗜𝗞𝗭 ⟬ ᴏᴡɴᴇʀ ⟭\n╰─────────\n\n© Dikz`;
        //koncol
        bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "owner") {
      bot.answerCallbackQuery(callbackQuery.id);
      bot.sendMessage(callbackQuery.from.id, "OWNER @DikzMarket01");
    }
  });
  // Event listener for button 'Start'
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "start") {
      const chatId = callbackQuery.message.chat.id;
      const startTime = Date.now();

      const DilzxMenu = `
Hello👋 @${sender}  I Am A Cpanel Dikz Created By My Owner t.me/DikzMarket01 Please Select The Menu \n╭───『乂 OWNER MENU 』\n│不 /addowner\n│不 /addprem\n│不 /delowner\n│不 /delprem\n│不 /listsrv\n│不 /listusr\n│不 /delsrv\n│不 /delusr\n╰─────────☻\n\n╭───『乂 Thanks To 』 :\n│Allah Swt (My God) \n│Ayah & Ibu (My Parents)\n│Dilzx (Owner)\n╰─────────☻`;
      const message = DilzxMenu;
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [
            { text: "[ CREATE PANEL2 ]", callback_data: "cpanel2" },
              { text: "[ CREATEPANEL ]", callback_data: "createpanel" },
            ],
            [
              { text: "[ OWNERMENU ]", callback_data: "ownermenu" },
              { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" },
            ],
          ],
        },
      };
      bot.answerCallbackQuery(callbackQuery.id);
      bot.editMessageCaption(message, {
        chat_id: chatId,
        message_id: callbackQuery.message.message_id,
        reply_markup: keyboard,
        parse_mode: "Markdown",
      });
    }
  });
  //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
  // ramlist2
  const message = DilzxMenu;
  const keyboard = {
    caption: message,
    reply_markup: {
      inline_keyboard: [
        [
            { text: "[ CREATEPANEL2】", callback_data: "cpanel2" },
          { text: "[ CREATEPANEL ]", callback_data: "createpanel" },
        ],
        [
          { text: "[ OWNERMENU ]", callback_data: "ownermenu" },
          { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" }
        ],
      ],
    },
  };
  bot.sendVideo(chatId, settings.video, keyboard);
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "kembali") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "Hallo I Am a Cpanel Bot By DikzMarket01 Vip. If there are any problems such as bugs, you can contact the admin @DikzMarket01 Thank You. Please select the menu below, Happy Using And Enjoy\n\n╭─❍ 𝑺𝑬𝑳𝑬𝑪𝑻 𝑻𝑶 𝑴𝑬𝑵𝑼\n│ ▢ ᴏᴡɴᴇʀᴍᴇɴᴜ  \n│ ▢ ᴄᴘᴀɴᴇʟᴍᴇɴᴜ \n│ ▢ ᴄᴘᴀɴᴇʟᴍᴇɴᴜ² (ᴄᴏᴍɪɴɢ sᴏᴏɴ) \n│ ▢ ғᴜɴᴍᴇɴᴜ (ᴄᴏᴍɪɴɢ sᴏᴏɴ)\n│ ▢ ᴘᴀʏᴍᴇɴᴛ \n╰─────────────\n\n╭─❍ 𝑻𝑯𝑨𝑵𝑲 𝑻𝑶\n│▢ 𝗔𝗟𝗟𝗔𝗛 ⟬ ᴍʏ ɢᴏᴅ ⟭\n│▢ 𝗕𝗢𝗧𝗛 𝗣𝗔𝗥𝗘𝗡𝗧𝗦\n│▢ 𝗗𝗜𝗞𝗭 ⟬ ᴏᴡɴᴇʀ ⟭\n╰─────────\n\n© DikzMarket01";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
          { text: "[ CREATEPANEL2】", callback_data: "cpanel2" },
          { text: "[ CREATEPANEL ]", callback_data: "createpanel" },
        ],
        [
          { text: "[ OWNERMENU ]", callback_data: "ownermenu" },
          { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" }
          ],
          
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "createpanel") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "Hello👋 I Am A Cpanel DikzMarket01 Created By My Owner t.me/DikzMarket01 Please Select The Menu \n╭────『乂 CREATE PANEL MENU 』\n│不 /1gb nama,id tele\n│不 /2gb nama,id tele\n│不 /3gb nama,id tele\n│不 /4gb nama,id tele\n│不 /5gb nama,id tele\n│不 /6gb nama,id tele\n│不 /7gb nama,id tele\n│不 /8gb nama,id tele\n│不 /9gb nama,id tele\n│不 /10gb nama,id tele\n│不 /unli nama,id tele\n│不 /admin nama,id tele\n╰──────────☻   \nCara Cek Id Tele? Ketik /cekid aja\n\n╭───『乂 Thanks To 』\n│Allah Swt (My God) \n│Ayah & Ibu (My Parents)\n│DikzMarket01 (Owner\n╰─────────☻";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "[ BACK ]", callback_data: "kembali" },
            { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" },
          ],
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "cpanel2") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "Hello👋 I Am A Cpanel DikzMarket01 Created By My Owner t.me/DikzMarket01 Please Select The Menu \n╭────『乂 CREATE PANEL MENU 』\n│不 /1gbV2 nama,id tele\n│不 /2gbV2 nama,id tele\n│不 /3gbV2 nama,id tele\n│不 /4gbV2 nama,id tele\n│不 /5gbV2 nama,id tele\n│不 /6gbV2 nama,id tele\n│不 /7gbV2 nama,id tele\n│不 /8gbV2 nama,id tele\n│不 /9gbV2 nama,id tele\n│不 /10gbV2 nama,id tele\n│不 /unliV2 nama,id tele\n│不 /cadminV2 nama,id tele\n╰──────────☻   \nCara Cek Id Tele? Ketik /cekid aja\n\n╭───『乂 Thanks To 』\n│Allah Swt (My God) \n│Ayah & Ibu (My Parents)\n│DikzMarket01 (Owner\n╰─────────☻";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "[ BACK ]", callback_data: "kembali" },
            { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" },
          ],
        ],
      },
    });
  }
});
bot.on("callback_query", (callbackQuery) => {
  if (callbackQuery.data === "ownermenu") {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage =
      "Hello👋 I Am A Cpanel DikzMarket01 Created By My Owner t.me/DikzMarket01 Please Select The Menu \n╭───『乂 OWNER MENU 』\n│不 /addowner\n│不 /addprem\n│不 /delowner\n│不 /delprem\n│不 /listsrv\n│不 /listusr\n│不 /delsrv\n│不 /delusr\n│不 /list_srvV2\n│不 /list_usrV2\n│不 /del_usrV2\n│不 /del_srvV2\n╰─────────☻\n\n╭───『乂 Thanks To 』 :\n│Allah Swt (My God) \n│Ayah & Ibu (My Parents)\n│DikzMarket01 (Owner)\n╰─────────☻";
    bot.editMessageCaption(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "[ BACK ]", callback_data: "kembali" },
            { text: "[ OWNER ]", url: "https://t.me/DikzMarket01" },
          ],
        ],
      },
    });
  }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// payment
bot.onText(/\/domain/, (msg) => {
    const chatId = msg.chat.id;
      const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
      const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
    const user = msg.from.username;
    bot.sendVideo(chatId, settings.video, { caption: `Helo @${user} This is the domain of server panel 1 Use it well, don't ddos and share it👍`, 
    'reply_markup' :{
    'inline_keyboard': [[{ 'text': 'DOMAIN', 'url': settings.domain }],
                     [{ 'text': 'OWNER', 'url': 'https://t.me/DikzMarket01' }]]
        }    })              
    });
    bot.onText(/\/DomainV2/, (msg) => {
    const chatId = msg.chat.id;
      const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
      const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
    const user = msg.from.username;
    bot.sendVideo(chatId, settings.video, { caption: `Helo @${user} This is the domain of server panel 1 Use it well, don't ddos and share it👍`, 
    'reply_markup' :{
    'inline_keyboard': [[{ 'text': 'DOMAIN', 'url': settings.domainV2 }],
                     [{ 'text': 'OWNER', 'url': 'https://t.me/DikzMarket01' }]]
        }    })              
    });
bot.onText(/\/tes/, (msg) => {
    const chatId = msg.chat.id;
    
    bot.sendMessage(chatId, 'Kontolodon',
                    {
   'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'TESTI', 'url': 'https://t.me/DikzMarket011'},
            { 'text': 'OWNER', 'url': 'https://t.me/DikzMarket01'}]]
        }    })              
    });
bot.onText(/\/payment/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, `Hello👋 I Am A Cpanel Dikz Created By My Owner t.me/DikzMarket01 Please Select The Menu 
╭───『乂 PAYMENT 』
│不 /dana
│不 /qris
╰────────☻    
NOTE :
SERTAKAN BUKTI PADA OWNER TF DI SETIAP PEMBAYARAN,GA ADA BUKTI TF? GA AKAN DI PROSES
    CONTACT OWNER? PENCET DI BAWAH👇
`, {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'TESTI', 'url': 'https://t.me/DikzMarket011'},
            { 'text': 'OWNER', 'url': 'https://t.me/DikzMarket01'}]]
        }
    })
})
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// PANEL
bot.onText(/\/panel_menu/, (msg) => {
    const chatId = msg.chat.id;
    const messageId = callbackQuery.message.message_id;
    const sender = msg.from.username;
    const caption = `Hello👋 @${sender}  I Am A Cpanel Dilzx Created By My Owner t.me/DikzMarket01 Please Select The Menu \n╭────『乂 CREATE PANEL MENU 』\n│不 /1gb nama,id tele\n│不 /2gb nama,id tele\n│不 /3gb nama,id tele\n│不 /4gb nama,id tele\n│不 /5gb nama,id tele\n│不 /6gb nama,id tele\n│不 /7gb nama,id tele\n│不 /8gb nama,id tele\n│不 /9gb nama,id tele\n│不 /10gb nama,id tele\n│不 /unli nama,id tele\n│不 /admin nama,id tele\n╰──────────☻   \nCara Cek Id Tele? Ketik /cekid aja\n\n╭───『乂 Thanks To 』\n│Allah Swt (My God) \n│Ayah & Ibu (My Parents)\n│DikzMarket01 (Owner\n╰─────────☻`;
        
      });
bot.onText(/\/panel/, (msg) => {
      const chatId = msg.chat.id;
  const sender = msg.from.username;
  const owner = '8636700791'; // Ganti dengan ID pemilik bot 
  const andre = `
╔═─═⊱ ᴍᴇᴍʙᴜᴀᴛ ᴘᴀɴᴇʟ
┃⬡ ᴜꜱᴇʀ : ${sender}
┃⬡ ʀᴀᴍ ᴜsᴇʀɴᴀᴍᴇ,ɪᴅᴛᴇʟᴇ
┃⬡ ᴄᴏɴᴛᴏʜ : /𝟷ɢʙ ${sender},id
┃⬡ ᴍᴇʟɪʜᴀᴛ ram ᴋᴇᴛɪᴋ /createpanelmenu
╰═─══─══─══─══─══─═⬡  
`;
    bot.sendVideo(chatId, settings.video, { caption: andre, parse_mode: 'Markdown', reply_markup: {                            inline_keyboard: [[{ text: "OWNER", url: "https://t.me/DikzMarket01" },
{ text: "ROOM PUBLIC", url: "https://t.me/DikzMarket011" }]],
    }
   })
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// DANA
bot.onText(/\/dana/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, `
╭───『乂 DANA PAYMENT 』
│ minta atemin
│A/N : 
╰─────────☻
    
NOTE :
SERTAKAN BUKTI TF PADA OWNER DI SETIAP PEMBAYARAN, GA ADA BUKTI TF? GA AKAN DI PROSES
CONTACT OWNER? PENCET DI BAWAH👇`, {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': '[All Testi Dilzx]', 'url': 'https://t.me/DikzMarket011'},
            { 'text': '[DILZXDev]', 'url': 'https://t.me/DikzMarket01'}]]
        }
    })
})
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// QRIS
bot.onText(/\/qris/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, `SILAHKAN TEKAN
TOMBOL DI BAWAH
UNTUK MELIHAT QRIS
    
NOTE :
SERTAKAN BUKTI PADA OWNER TF DI SETIAP PEMBAYARAN
    CONTACT OWNER? https://t.me/XYDILZX`, {
        'reply_markup' :{
            'inline_keyboard': [[{ 'text': 'QRIS', 'url': 'https://files.catbox.moe/p3gwhw.jpeg'}]]
        }
    })
})
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// CREATE ADMIN
bot.onText(/\/cadmin (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Owner Only😹', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const commandParams = match[1].split(',');
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[0].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(chatId, 'Format Salah! Penggunaan: /admin nama,idtele');
    return;
  }
  const password = panelName + "1127";
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "DikzMarket01",
        language: "en",
        root_admin: true,
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
➟ LOGIN: ${domain}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(telegramId, `
𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username} 
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password} 
• 𝗟𝗼𝗴𝗶𝗻 : ${domain} 

𝗥𝘂𝗹𝗲𝘀 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
• Simpan Baik² Data Akun Ini
• Buat Panel Seperlunya Aja, Jangan Asal Buat!
• Garansi Aktif 10 Hari
• Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
    `);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, 'Terjadi kesalahan dalam pembuatan admin panel. Silakan coba lagi nanti.');
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminIDs = JSON.parse(data);
  }
});
// CEK ID
bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const id = msg.from.id;
    const owner = '8636700791'; // Ganti dengan ID pemilik bot 
    const text12 = `Halo @${sender}    \nID Telegram Anda: ${id}\nFull Name Anda : ${sender}`;
    bot.sendVideo(chatId, settings.video, { caption: text12, parse_mode: 'Markdown', reply_markup: {                            inline_keyboard: [[{ text: "OWNER", url: "https://t.me/DikzMarket01" },
{ text: "ROOM PUBLIC", url: "https://t.me/DikzMarket011" }]],
    }
   })
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listsrv
bot.onText(/\/listsrv/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;   
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    if (!isAdmin) {
        bot.sendMessage(chatId, ' Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }
    let page = 1;
    try {
        let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let servers = res.data;
        let messageText = "Daftar server aktif yang dimiliki:\n\n";
        for (let server of servers) {
            let s = server.attributes;

            let f3 = await fetch(`${domain}/api/client/servers/${s.uuid.split('-')[0]}/resources`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${pltc}`
                }
            });
            let data = await f3.json();
            let status = data.attributes ? data.attributes.current_state : s.status;

            messageText += `ID Server: ${s.id}\n`;
            messageText += `Nama Server: ${s.name}\n`;
            messageText += `Status: ${status}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//delsrv
bot.onText(/\/delsrv(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const srv = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        }); 
        return;
    }

    if (!srv) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1');
        return;
    }

    try {
        let f = await fetch(`${domain}/api/application/servers/${srv}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'SERVER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE SERVER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listusr
bot.onText(/\/listusr/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut daftar users aktif yang dimiliki :\n\n";
        for (let user of users) {
            let u = user.attributes;
                messageText += `\x0aID Users: ${u.id}`
                messageText += `\x0aName Users: ${u.username}`;
            }
            
        messageText += `\x0aPage : ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total User : ${res.meta.pagination.count}`;
        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
bot.onText(/\/listuser2/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '2';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut daftar users aktif yang dimiliki :\n\n";
        for (let user of users) {
            let u = user.attributes;
                messageText += `\x0aID Users: ${u.id}`
                messageText += `\x0aName Users: ${u.username}`;
            }
            
        messageText += `\x0aPage : ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total User : ${res.meta.pagination.count}`;
        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//delusr
bot.onText(/\/delusr(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const usr = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }

    if (!usr) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delusr 1');
        return;
    }

try {
        let f = await fetch(`${domain}/api/application/users/${usr}`, {
	            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'USER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE USER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can use this command');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the Owner Can Perform This Order');
    }
});
//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 1gb
bot.onText(/\/1gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /1gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '1gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '1024';
  const cpu = '30';
  const disk = '1024';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 2gb
bot.onText(/\/2gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /2gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '2gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '2048';
  const cpu = '60';
  const disk = '2048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}_${u}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat`
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 3gb
bot.onText(/\/3gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id)); 
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: '@DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /3gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '3gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '3072';
  const cpu = '90';
  const disk = '3072';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);

    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 4gb
bot.onText(/\/4gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: '@DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /4gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '4gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '4048';
  const cpu = '110';
  const disk = '4048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 5gb
bot.onText(/\/5gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /5gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '5gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '5048';
  const cpu = '140';
  const disk = '5048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 6gb
bot.onText(/\/6gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /6gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '6gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '6048';
  const cpu = '170';
  const disk = '6048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 7gb
bot.onText(/\/7gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /7gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '7gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '7048';
  const cpu = '200';
  const disk = '7048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 8gb
bot.onText(/\/8gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /8gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '8gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '8048';
  const cpu = '230';
  const disk = '8048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 9gb
bot.onText(/\/9gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /9gb nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '9gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '9048';
  const cpu = '260';
  const disk = '9048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 10gb
bot.onText(/\/10gb (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /10gb nama,id tele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '10gb';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '10000';
  const cpu = '500';
  const disk = '15000';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// UNLI
bot.onText(/\/unli (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /unli nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + 'unli';
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = '0';
  const cpu = '0';
  const disk = '0';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = `${username}001`;
  let user;
  let server;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domain}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 1gbV2
bot.onText(/\/1gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /1gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '1gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '1024';
  const cpu = '30';
  const disk = '1024';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);

    if (akunlo) {
    
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 2gbV2
bot.onText(/\/2gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /2gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '2gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '2048';
  const cpu = '60';
  const disk = '2048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}_${u}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat`
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 3gbV2
bot.onText(/\/3gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id)); 
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: '@DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /3gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '3gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '3072';
  const cpu = '90';
  const disk = '3072';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);

    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 4gbV2
bot.onText(/\/4gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: '@DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /4gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '4gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '4048';
  const cpu = '110';
  const disk = '4048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 5gbV2
bot.onText(/\/5gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /5gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '5gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '5048';
  const cpu = '140';
  const disk = '5048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 6gbV2
bot.onText(/\/6gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /6gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '6gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '6048';
  const cpu = '170';
  const disk = '6048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 7gbV2
bot.onText(/\/7gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /7gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '7gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '7048';
  const cpu = '200';
  const disk = '7048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 8gbV2
bot.onText(/\/8gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /8gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '8gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '8048';
  const cpu = '230';
  const disk = '8048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 9gbV2
bot.onText(/\/9gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /9gbV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '9gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '9048';
  const cpu = '260';
  const disk = '9048';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// 10gbV2
bot.onText(/\/10gbV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /10gbV2 nama,id tele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + '10gbV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '10000';
  const cpu = '500';
  const disk = '15000';
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// UNLI
bot.onText(/\/unliV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));  
  if (!isPremium) {
    bot.sendMessage(chatId, 'Commands Only For Premium Users', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Hubungi Developer', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const t = text.split(',');
  if (t.length < 2) {
    bot.sendMessage(chatId, 'Invalid format. Usage: /unliV2 nama,idtele');
    return;
  }
  const username = t[0];
  const u = t[1];
  const name = username + 'unliV2';
  const egg = settings.eggsV2;
  const loc = settings.locV2;
  const memo = '0';
  const cpu = '0';
  const disk = '0';
  const email = `${username}@gmail.com`;
  const akunlo = settings.pp;
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = `${username}279`;
  let user;
  let server;
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: 'en',
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      if (data.errors[0].meta.rule === 'unique' && data.errors[0].meta.source_field === 'email') {
        bot.sendMessage(chatId, 'Email already exists. Please use a different email.');
      } else {
        bot.sendMessage(chatId, `Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        name: name,
        description: '',
        user: user.id,
        egg: parseInt(egg),
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: spc,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start'
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    const data2 = await response2.json();
    server = data2.attributes;
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
  if (user && server) {
    bot.sendMessage(chatId, `ʙᴇʀɪᴋᴜᴛ ᴅᴀᴛᴀ ᴘᴀɴᴇʟ ᴀɴᴅᴀ
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    if (akunlo) {
      bot.sendPhoto(u, akunlo, {
        caption: `𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗸𝘂𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username}
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password}
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2}
𝗘𝘅𝗽𝗶𝗿𝗲𝗱 𝗦𝗲𝗿𝘃𝗲𝗿 : 1 Bulan

𝗥𝘂𝗹𝗲𝘀 𝗣𝗲𝗺𝗯𝗲𝗹𝗶𝗮𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
• Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
• Garansi Aktif 10 Hari (1x replace)
• Claim Garansi Wajib Membawa Bukti Tf & Ss Chat `
        });
      bot.sendMessage(chatId, 'Data panel berhasil dikirim ke ID Telegram yang dimaksud.');
    }
  } else {
    bot.sendMessage(chatId, 'Gagal membuat data panel. Silakan coba lagi.');
  }
});
bot.onText(/\/cadminV2 (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Owner Only😹', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
          ]
        ]
      }
    });
    return;
  }
  const commandParams = match[1].split(',');
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[0].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(chatId, 'Format Salah! Penggunaan: /cadminV2 nama,idtele');
    return;
  }
  const password = panelName + "1127";
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${pltaV2}`
      },
      body: JSON.stringify({
        email: `${panelName}@gmail.com`,
        username: panelName,
        first_name: panelName,
        last_name: "Dilzx",
        language: "en",
        root_admin: true,
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
➟ LOGIN: ${domainV2}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(telegramId, `
𝗕𝗲𝗿𝗵𝗮𝘀𝗶𝗹 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹 ✅

• 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${user.username} 
• 𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 : ${password} 
• 𝗟𝗼𝗴𝗶𝗻 : ${domainV2} 

𝗥𝘂𝗹𝗲𝘀 𝗔𝗱𝗺𝗶𝗻 𝗣𝗮𝗻𝗲𝗹 ⚠️
• Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
• Simpan Baik² Data Akun Ini
• Buat Panel Seperlunya Aja, Jangan Asal Buat!
• Garansi Aktif 10 Hari
• Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
    `);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, 'Terjadi kesalahan dalam pembuatan admin panel. Silakan coba lagi nanti.');
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminIDs = JSON.parse(data);
  }
});
bot.onText(/\/list_srvV2/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;   
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));   
    if (!isAdmin) {
        bot.sendMessage(chatId, ' Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }
    let page = 1;
    try {
        let f = await fetch(`${domainV2}/api/application/servers?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${pltaV2}`
            }
        });
        let res = await f.json();
        let servers = res.data;
        let messageText = "Daftar server aktif yang dimiliki:\n\n";
        for (let server of servers) {
            let s = server.attributes;

            let f3 = await fetch(`${domainV2}/api/client/servers/${s.uuid.split('-')[0]}/resources`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${pltcV2}`
                }
            });
            let data = await f3.json();
            let status = data.attributes ? data.attributes.current_state : s.status;

            messageText += `ID Server: ${s.id}\n`;
            messageText += `Nama Server: ${s.name}\n`;
            messageText += `Status: ${status}\n\n`;
        }

        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
//delsrv
bot.onText(/\/del_srvV2(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const srv = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }

    if (!srv) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1');
        return;
    }

    try {
        let f = await fetch(`${domainV2}/api/application/servers/${srv}`, {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${pltaV2}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'SERVER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE SERVER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listusr
bot.onText(/\/listusrV2/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domainV2}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${pltaV2}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut daftar users aktif yang dimiliki :\n\n";
        for (let user of users) {
            let u = user.attributes;
                messageText += `\x0aID Users: ${u.id}`
                messageText += `\x0aName Users: ${u.username}`;
            }
            
        messageText += `\x0aPage : ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total User : ${res.meta.pagination.count}`;
        bot.sendMessage(chatId, messageText);
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
bot.onText(/\/del_usrV2(.*)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const usr = match[1].trim();

    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Owner Only', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'OWNER', url: 'https://t.me/DikzMarket01' }
                    ]
                ]
            }
        });
        return;
    }

    if (!usr) {
        bot.sendMessage(chatId, 'Mohon masukkan ID server yang ingin dihapus, contoh: /delusr 1');
        return;
    }

try {
        let f = await fetch(`${domainV2}/api/application/users/${usr}`, {
	            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${pltaV2}`
            }
        });

        let res = f.ok ? { errors: null } : await f.json();

        if (res.errors) {
            bot.sendMessage(chatId, 'USER NOT FOUND');
        } else {
            bot.sendMessage(chatId, 'SUCCESSFULLY DELETE THE USER');
        }
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan saat menghapus server.');
    }
});

bot.on('callback_query', (callbackQuery) => {
    const chatId = msg.chat.id;
    const messageId = callbackQuery.message.message_id;
    const sender = msg.from.username;


      if (callbackQuery.data === 'owner_menu') {
        sendOwnerMenu(chatId, messageId, sender);
    } else if (callbackQuery.data === 'paneelygy') {
        sendPanelMenu2(chatId, messageId, sender);
    } else if (callbackQuery.data === 'menu_start') {
        sendStartMenu(chatId, messageId, sender);
    }

    bot.answerCallbackQuery(callbackQuery.id);
});

    console.clear();
    console.log(chalk.bold.white(`
                     ⠀⠀⠀⠀⣀⣤⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣿⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣶⣿⣿⣿⡅⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⣀⣀⣀⣀⣀⣀⣀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣤⣤⣤⣤⣴⣿⣿⣿⣿⣯⣤⣶⣶⣾⣿⣶⣶⣿⣿⣿⣿⣿⡿⠿⠟⠛⠉⠉⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠉⠁⠈⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣶⠶⠶⠦⠄⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⡿⠟⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣾⣿⣟⣡⣤⣾⣿⣿⣿⣿⣿⣿⢏⠉⠛⣿⣿⣿⣿⣿⣿⣿⣿⣿⡻⢿⣿⣿⣦⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣀⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠈⠻⡄⠁⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠈⠙⠻⣿⣆⠀⠀⠀⠀
⠀⠀⠀⠀⢰⣿⣿⣿⣿⡿⠛⠉⠉⠉⠛⠛⠛⠛⠋⠁⠀⠀⠀⠁⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠈⠙⢧⠀⠀⠀
⠀⠀⠀⠀⠀⠙⠿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠙⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣤⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⢹⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠋⠁⠀⠀⠀⠀⠈⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⠛⢋⣩⡿⠿⠿⠟⠛⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠠⣄⣀⡀⠀⠀⠀⠀⠀⠐⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣾⣿⣿⣿⣿⣿⣿⣿⠻⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⢿⣶⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢰⣿⣿⣿⣿⣿⣿⣿⣿⡄⠙⢿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠠⣤⣀⠀⠀⠀⠠⣄⣀⣀⡉⢻⣿⣿⣿⣶⣄⡀⠀⠀⠀⠀⠀⠀⠀
⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣦⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠀⠀⠀⠀
⠀⢻⡟⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⠛⠋⠉⠀⠀⢀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀⠀⠀
⠀⠀⠃⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣶⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠈⠉⠻⢿⣿⣿⣿⣷⡄⠀
⠀⠀⠀⠀⢸⣿⣿⡟⠙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠛⠛⣿⣿⣿⣿⣿⣧⣀⣀⡄⠀⠀⠀⠀⠀⠀⠈⣿⡿⣿⣿⣷⠀
⠀⠀⠀⠀⢸⣿⡿⠁⠀⠀⠀⠙⠻⠿⣟⠻⢿⣿⣿⣿⣷⣦⡀⠀⠈⠻⢿⣿⣿⣭⣉⡉⠀⠀⠀⠀⠀⠀⠀⠀⠘⠀⠸⣿⣿⡄
⠀⠀⠀⠀⣸⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⢿⣿⣿⣦⡀⠀⠀⠀⠉⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁
⠀⠀⠀⠠⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⡟⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠟⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀`));
    console.log(chalk.bold.white("𝘿𝙄𝗞𝗭 𝘾𝙋𝘼𝙉𝙀𝙇"));
    console.log(chalk.bold.white("DEVELOPER:") + chalk.bold.blue("DikzMarket01"));
    console.log(chalk.bold.white("VERSION:") + chalk.bold.blue("𝗩𝟭.𝟬. \n\n"));
    console.log(chalk.bold.green("Bot Is Connect. . ."));
