const settings = {
  
//TOKEN DAN OWNER

  token: '8958758600:AAF1bSd4gas5KOjCEml2JYTNEfux1da2pR4', // Token Bot
  adminId: '8636700791', // Id Tele Mu

//SETTING TELE X FOTO

pp: 'https://files.catbox.moe/9d6cf4.png',
video: 'https://files.catbox.moe/u2vh3i',
asu: 'https://files.catbox.moe/u2vh3i',
suu: 'https://files.catbox.moe/u2vh3i',
asyu: 'https://files.catbox.moe/u2vh3i',
asy: 'https://files.catbox.moe/u2vh3i',
urladmin: 't.me/DikzMarket01',

//SETTING PLTA,PLTC,DOMAIN

  domain: 'ISI DOMAIN LU',
  plta: 'PLTA LU',
  pltc: 'PLTC LU',
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15',
  
//SETTING PLTA,PLTC,DOMAINV2
domainV2: 'DOMAIN SERVER 2',
  pltaV2: 'PLTA SERVER 2',
  pltcV2: 'PLTC SERVER2',
  locV2: '1', // Isi dengan lokasi yang diinginkan
  eggsV2: '15'
};

module.exports = settings;